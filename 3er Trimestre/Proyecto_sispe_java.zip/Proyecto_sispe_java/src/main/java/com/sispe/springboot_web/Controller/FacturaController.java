package com.sispe.springboot_web.Controller;

import com.sispe.springboot_web.Model.Factura;
import com.sispe.springboot_web.Model.Pedido;
import com.sispe.springboot_web.Model.SesionMesa;
import com.sispe.springboot_web.Repository.DetallePedidoAdicionRepository;
import com.sispe.springboot_web.Repository.DetallePedidoRepository;
import com.sispe.springboot_web.Repository.FacturaMetodoPagoRepository;
import com.sispe.springboot_web.Repository.FacturaRepository;
import com.sispe.springboot_web.Repository.PedidoRepository;
import com.sispe.springboot_web.Repository.SesionMesaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/facturas")
public class FacturaController {
    private final FacturaRepository facturas;
    private final PedidoRepository pedidos;
    private final SesionMesaRepository sesiones;
    private final DetallePedidoRepository detalles;
    private final DetallePedidoAdicionRepository detalleAdiciones;
    private final FacturaMetodoPagoRepository facturaMetodoPagos;

    public FacturaController(FacturaRepository facturas, PedidoRepository pedidos, SesionMesaRepository sesiones,
                              DetallePedidoRepository detalles, DetallePedidoAdicionRepository detalleAdiciones,
                              FacturaMetodoPagoRepository facturaMetodoPagos) {
        this.facturas = facturas;
        this.pedidos = pedidos;
        this.sesiones = sesiones;
        this.detalles = detalles;
        this.detalleAdiciones = detalleAdiciones;
        this.facturaMetodoPagos = facturaMetodoPagos;
    }

    @GetMapping public String index(Model model) { model.addAttribute("facturas", facturas.findAll()); return "facturas/index"; }

    @GetMapping("/{id}")
    public String ver(@PathVariable Long id, Model model) {
        Factura factura = facturas.findById(id).orElseThrow();
        Pedido pedido = pedidos.findById(factura.getPedidoId()).orElseThrow();
        SesionMesa sesion = pedido.getSesionQrId() == null ? null : sesiones.findById(pedido.getSesionQrId()).orElse(null);

        model.addAttribute("factura", factura);
        model.addAttribute("pedido", pedido);
        model.addAttribute("sesion", sesion);
        model.addAttribute("items", detalles.findByPedidoId(pedido.getId()));
        model.addAttribute("adicionesRepo", detalleAdiciones);
        model.addAttribute("pago", facturaMetodoPagos.findByFactura_Id(id).orElse(null));
        return "facturas/ver";
    }
}